from flask import Flask, render_template, request
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

app = Flask(__name__)
world_cup=pd.read_csv('datasets/2023ODI.csv')
results=pd.read_csv('datasets/results.csv')
worldcup_teams=['England', ' South Africa', '', 'Netherlands',
                  'Pakistan', 'New Zealand', 'Sri Lanka', 'Afghanistan',
                  'Australia', 'Bangladesh', 'India']
icc_teams_1=results[results['Team_1'].isin(worldcup_teams)]
icc_teams_2=results[results['Team_2'].isin(worldcup_teams)]
icc_teams=pd.concat((icc_teams_1, icc_teams_2))
icc_teams.drop_duplicates()
wc_teams=icc_teams.drop(['date','Margin'], axis=1)
wc_teams=wc_teams.reset_index(drop=True)
wc_teams.loc[wc_teams.Winner == wc_teams.Team_1,'winning_team']=1
wc_teams.loc[wc_teams.Winner == wc_teams.Team_2, 'winning_team']=2
wc_teams=wc_teams.drop(['winning_team'], axis=1)
final=pd.get_dummies(wc_teams, prefix=['Team_1', 'Team_2', 'Ground','Weather','Pitch'], columns=['Team_1', 'Team_2', 'Ground','Weather','Pitch'])
X=final.drop(['Winner'], axis=1)
y=final["Winner"]
X_train, X_test, y_train, y_test=train_test_split(X, y, test_size=0.30, random_state=42)
rf=RandomForestClassifier(n_estimators=100, max_depth=20, random_state=0)
rf.fit(X_train, y_train)

@app.route('/')
def welcome():
    return render_template('welcome.html')

@app.route('/predict', methods=['GET','POST'])
def predict():
    if request.method == 'POST':
        team1=request.form['team1']
        team2=request.form['team2']
        venue=request.form['venue']
        matches=[(team1, team2)]
        ranking=pd.read_csv('datasets/icc_rankings.csv')
        def predict(matches, ranking, final, rf):
            positions=[]
            for match in matches:
                positions.append(ranking.loc[ranking['Team'] == match[0], 'Position'].iloc[0])
                positions.append(ranking.loc[ranking['Team'] == match[1], 'Position'].iloc[0])
            pred_set=[]
            i=0
            j=0
            while i<len(positions):
                dict1={}
                if positions[i]<positions[i + 1]:
                    dict1.update({'Team_1': matches[j][0], 'Team_2': matches[j][1]})
                else:
                    dict1.update({'Team_1': matches[j][1], 'Team_2': matches[j][0]})
                pred_set.append(dict1)
                i+=2
                j+=1
            pred_set=pd.DataFrame(pred_set)
            backup_pred_set=pred_set
            pred_set=pd.get_dummies(pred_set, prefix=['Team_1', 'Team_2'], columns=['Team_1', 'Team_2'])
            missing_cols2=set(final.columns)-set(pred_set.columns)
            for c in missing_cols2:
                pred_set[c]=0
            pred_set=pred_set[final.columns]
            pred_set=pred_set.drop(['Winner'], axis=1)
            predictions=rf.predict(pred_set)
            predicted_winner=[]
            for i in range(len(pred_set)):
                team1=backup_pred_set.iloc[i, 1]
                team2=backup_pred_set.iloc[i, 0]
                if predictions[i] == 1:
                    predicted_winner.append(f"Winner: {team1}")
                else:
                    predicted_winner.append(f"Winner: {team2}")
            return predicted_winner
        
        predicted_winner = predict(matches, ranking, final, rf)
        return render_template('result.html', team1=team1, team2=team2, venue=venue, winner=predicted_winner)
    return render_template('predict.html')

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/schedule')
def schedule():
    return render_template('schedule.html')

if __name__ == '__main__':
    app.run(debug=True)
