import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
world_cup = pd.read_csv('datasets/2023ODI.csv')
results = pd.read_csv('datasets/results.csv')
worldcup_teams = ['England', ' South Africa', 'Netherlands','Pakistan', 'New Zealand', 'Sri Lanka', 'Afghanistan','Australia', 'Bangladesh', 'India']
icc_teams_1 = results[results['Team_1'].isin(worldcup_teams)]
icc_teams_2 = results[results['Team_2'].isin(worldcup_teams)]
icc_teams = pd.concat((icc_teams_1, icc_teams_2))
icc_teams.drop_duplicates()
wc_teams = icc_teams.drop(['date'], axis=1)
wc_teams = wc_teams.reset_index(drop=True)
wc_teams.loc[wc_teams.Winner == wc_teams.Team_1,'winning_team']=1
wc_teams.loc[wc_teams.Winner == wc_teams.Team_2, 'winning_team']=2
wc_teams = wc_teams.drop(['winning_team'], axis=1)
final = pd.get_dummies(wc_teams, prefix=['Team_1', 'Team_2', 'Ground','Weather','Pitch'], columns=['Team_1', 'Team_2', 'Ground','Weather','Pitch'])
X = final.drop(['Winner','Margin'], axis=1)
Y = final["Winner"]
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.33, random_state=42)
lr = LogisticRegression()
lr.fit(X_train, Y_train)
score = lr.score(X_train, Y_train)
score2 = lr.score(X_test, Y_test)
print("Training set accuracy: ", score)
print("Test set accuracy: ", score2)