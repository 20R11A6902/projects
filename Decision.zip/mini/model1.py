import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
world_cup = pd.read_csv('datasets/2023ODI.csv')
results = pd.read_csv('datasets/results.csv')
worldcup_teams = ['England', ' South Africa', 'Netherlands','Pakistan', 'New Zealand', 'Sri Lanka', 'Afghanistan','Australia', 'Bangladesh', 'India']
icc_teams_1 = results[results['Team_1'].isin(worldcup_teams)]
icc_teams_2 = results[results['Team_2'].isin(worldcup_teams)]
icc_teams = pd.concat((icc_teams_1, icc_teams_2))
icc_teams.drop_duplicates()
wc_teams = icc_teams.drop(['date','Margin'], axis=1)
wc_teams = wc_teams.reset_index(drop=True)
wc_teams.loc[wc_teams.Winner == wc_teams.Team_1,'winning_team']=1
wc_teams.loc[wc_teams.Winner == wc_teams.Team_2, 'winning_team']=2
wc_teams = wc_teams.drop(['winning_team'], axis=1)
final = pd.get_dummies(wc_teams, prefix=['Team_1', 'Team_2', 'Ground','Weather','Pitch'], columns=['Team_1', 'Team_2', 'Ground','Weather','Pitch'])
X = final.drop(['Winner'], axis=1)
Y = final["Winner"]
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.33, random_state=42)
rf = RandomForestClassifier(n_estimators=200, max_depth=120, random_state=42)
rf.fit(X_train, Y_train)
score = rf.score(X_train, Y_train)
score2 = rf.score(X_test, Y_test)
print("Training set accuracy: ", score)
print("Test set accuracy: ", score2)
ranking = pd.read_csv('datasets/icc_rankings.csv')
fixtures = pd.read_csv('datasets/fixtures.csv')
pred = []
fixtures.insert(1, 'first_position', fixtures['Team_1'].map(ranking.set_index('Team')['Position']))
fixtures.insert(2, 'second_position', fixtures['Team_2'].map(ranking.set_index('Team')['Position']))
fixtures = fixtures.iloc[:45, :]
for index, row in fixtures.iterrows():
    if row['first_position'] < row['second_position']:
        pred.append({'Team_1': row['Team_1'], 'Team_2': row['Team_2'], 'winning_team': None})
    else:
        pred.append({'Team_1': row['Team_2'], 'Team_2': row['Team_1'], 'winning_team': None})
pred = pd.DataFrame(pred)
pred_set = pred
pred = pd.get_dummies(pred, prefix=['Team_1', 'Team_2'], columns=['Team_1', 'Team_2'])
missing_cols = set(final.columns) - set(pred.columns)
pred = pd.concat([pred, pd.DataFrame(0, index=pred.index, columns=list(missing_cols))], axis=1)
pred = pred[final.columns]
pred = pred.drop(['Winner'], axis=1)
predictions = rf.predict(pred)
for i in range(fixtures.shape[0]):
    print(pred_set.iloc[i, 1] + " and " + pred_set.iloc[i, 0])
    if predictions[i] == 1:
        print("Winner: " + pred_set.iloc[i, 1])

    else:
        print("Winner: " + pred_set.iloc[i, 0])
    print("")
semi = [('South Africa', 'Australia'),('India', 'New Zealand')]
def predict(matches, ranking, final, rf):
    positions = []
    for match in matches:
        positions.append(ranking.loc[ranking['Team'] == match[0],'Position'].iloc[0])
        positions.append(ranking.loc[ranking['Team'] == match[1],'Position'].iloc[0])
    pred = []
    i = 0
    j = 0
    while i < len(positions):
        dict1 = {}
        if positions[i] < positions[i + 1]:
            dict1.update({'Team_1': matches[j][0], 'Team_2': matches[j][1]})
        else:
            dict1.update({'Team_1': matches[j][1], 'Team_2': matches[j][0]})
        pred.append(dict1)
        i += 2
        j += 1
    pred = pd.DataFrame(pred)
    pred_set = pred
    pred = pd.get_dummies(pred, prefix=['Team_1', 'Team_2'], columns=['Team_1', 'Team_2'])
    missing_cols2 = set(final.columns) - set(pred.columns)
    pred = pd.concat([pred, pd.DataFrame(0, index=pred.index, columns=list(missing_cols2))], axis=1)
    pred = pred[final.columns]
    pred = pred.drop(['Winner'], axis=1)
    predictions = rf.predict(pred)
    for i in range(len(pred)):
        print(pred_set.iloc[i, 1] + " and " + pred_set.iloc[i, 0])
        if predictions[i] == 1:
            print("Winner: " + pred_set.iloc[i, 1])
        else:
            print("Winner: " + pred_set.iloc[i, 0])
        print("")
predict(semi, ranking, final, rf)
finals = [('India', 'Australia')]
predict(finals, ranking, final, rf)